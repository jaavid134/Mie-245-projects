class Node:
    def __init__(self, value):
        """ Node class.  This does not need to be modified. """
        self.value = value
        self.next = None

class LinkedList:
    def __init__(self):
        """ Initialize head/tail to none (be sure to update these when appropriate). """
        self.head = None  
        self.tail = None 

    def insert_start(self, value):
        """ Inserts a Node with Value to the start of the LinkedList. """
        node = Node(value)
        node.next = self.head
        self.head = node
        if self.tail == None:
            self.tail = self.head
        return 

    def insert_end(self, value):
        """ inserts a Node with Value to the end of the LinkedList. """
        if self.tail == None:
            node = Node(value)
            self.head = node
            self.tail = node
            return

        iter = self.head
        while iter.next:
            iter = iter.next
        iter.next = Node(value)
        self.tail = iter.next
        return

    def search_for_node_by_value(self, value):
        """ Searches for a Node with Value in the LinkedList. """
        iter = self.head
        while iter:
            if value == iter.value:
                return iter
            else:
                iter = iter.next
        return None

    def delete_node_by_value(self, value):
        """ Deletes a Node with Value in the LinkedList. 
            If the node does not exist, then does nothing.
        """
        iter_0 = None
        iter_1 = self.head

        while iter_1:
            if iter_1.value == value:
                if iter_1 == self.head and iter_1 == self.tail:
                    self.head = None
                    self.tail = None
                    return
                elif iter_1 == self.head:
                    self.head = iter_1.next
                    return
                elif iter_1 == self.tail:
                    iter_0.next = None
                    self.tail = iter_0
                    return
                else:
                    iter_0.next = iter_1.next
                    return
            iter_0 = iter_1
            iter_1 = iter_1.next
                
        return



    
