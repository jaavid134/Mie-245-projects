In submitting this file, I confirm the work claimed to be done by myself, others, tools, and websites is accurate.

Sign: wuhungja

==================================================================================================================
For each section below, add a bullet where appropriate. Please follow the syntax from the examples below.

Syntax examples:

For functions or lines of code written by you:
- insert_start
- lines 1-5

For functions or lines of code written by others, generative AI tools, or leveraged from websites:
- insert_end - MIE245 student: FirstName, LastName
- search_for_node_by_value - Not an MIE245 student: FirstName, LastName, email
- lines 5-10 - ChatGPT
- lines 10-15 - https://www.geeksforgeeks.org/dsa/introduction-to-recursion-2/

Note: help from TAs or the instructor does not need to be documented.

==================================================================================================================

Functions or lines of code written by me:
- insert_start
- insert_end
- search_for_node_by_value
- delete_node_by_value

Functions or lines of code written by other students, people, or generative AI:
- None

Websites leveraged for help or code (include the full URL to the page):
- https://www.youtube.com/watch?v=qp8u-frRAnU&t=1254s
